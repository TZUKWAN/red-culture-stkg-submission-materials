# Round4 figure package

Figures 4, 5 and 9 are generated from the round4 scripts and the frozen T34/AUDIT_RESULTS inputs. Figures 3, 6, 7, 8 and 10 use the existing 170mm SVG/PDF/PNG source set. Figures 1 and 2 are inherited embedded framework diagrams; their original editable/vector source was not found in the workspace, so they are retained as raster evidence and remain a release limitation until the source is provided.
